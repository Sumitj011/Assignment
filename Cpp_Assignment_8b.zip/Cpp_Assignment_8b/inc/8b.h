#include<iostream>
#include<string>
#include<list>
#include <stack> 

using namespace std;
